# Guía Rápida (ES) — Migración Híbrida Post‑Cuántica

- KEM: X25519 + Kyber (ML‑KEM)
- Firmas: ECDSA + Dilithium
