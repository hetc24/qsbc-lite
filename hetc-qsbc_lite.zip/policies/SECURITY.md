# SECURITY Policy (ES/EN)

Report issues to security@hetc.example. Use responsible disclosure.
